<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller{

    public function log()
    {
        $this->load->view('Vlogin');
    }
    public function reg()
    {
        $this->load->view('Vregister');
    }
    public function home()
    {
        $this->load->view('Vhome');
    }
   
}