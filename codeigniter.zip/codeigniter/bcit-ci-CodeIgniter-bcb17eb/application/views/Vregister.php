<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reg</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    ="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  
</head>
<body style="background:#7895B2">
    <div style="padding:100px;">
        <form action="home"  method="POST">

    <?php if(isset($_GET['error'])) : ?>
                <div class="container-fluid">
                <div class="alert alert-danger text-center" style="width:500px;margin:auto" role="alert">
                <a href="loginF.php" class="btn btn-close" type="button" style="float:left"></a>
                    <span class="text-center"><?= $_GET['error'] ?></span>
                </div>
              </div>
            <?php endif ?>

        <div class="text-center fs-1"><h1 class="text-white" 
        style="font-family: 'Alfa Slab One', cursive;">SMK BISA</h1></div>
        <div class="container mt-3">
        <div class="row" >
        <div class="col-md-6 offset-md-3">
        <div class="card my-6"  style="background-color: #AEBDCA;">
            <form class="card-body cardbody-color p-lg-4 text-white ">
            <h2 class="mb-3 mt-4 text-center" style="color:rgb(61, 61, 61);">D A F T A R</h2>
              <div class="mb-3 mt-3 text-center fw-bold">
                NIS : <br>
                <input class="rounded-3 border-light" type="text" name="nis"
                 placeholder="masukan NIK anda" style="width: 300px;" required>
              </div>
              <div class="mb-3 mt-3 text-center fw-bold">
                Nama : <br>
                <input class="rounded-3 border-light" type="text" name="nama" 
                placeholder="masukan Nama anda" requtred style="width: 300px;" required>
              </div>
              <div class="text-center mt-3"> 
                <button type="submit" class="btn px-3 mb-3 fw-bold" style="width: 200px;background:#B4CDE6">Daftar</button> <br>
                <p><i>Sudah Punya Akun? Click <a href="login" class="text-danger">Login</a></i></p>
                </div>
              </div>
            </form>
        </div>
</body>
</html>